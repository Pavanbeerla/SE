const ROLE = {
    ADMIN: 'admin',
    FAC:'fac',
    BASIC: 'basic'
  }
  
  module.exports = {
    ROLE: ROLE,
    users: [
      { id: 1, name: 'Manvith', role: ROLE.ADMIN },
      { id: 2, name: 'Humes', role: ROLE.FAC },
      { id: 3, name: 'NKC', role: ROLE.BASIC }
    ],
    profiles: [
      { id: 1, name: "Manvith's Profile", userId: 1 },
      { id: 2, name: "humesh's Profile", userId: 2 },
      { id: 3, name: "NKC's Profile", userId: 3 }
    ]
  }